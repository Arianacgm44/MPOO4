//
//  ViewController.swift
//  TableView1
//
//  Created by Germán Santos Jaimes on 8/30/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var Resultado: UILabel!
    
    
    @IBOutlet weak var tablita: UITableView!
    var fruits = [estructura1] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fruits.append(estructura1(precio: 12, nombre: "Manzana", descripcion: "Bolsa de  100g, precio $12"))
        fruits.append(estructura1(precio: 10, nombre: "Plátano", descripcion: " Bolsa de 200g.  Precio $10"))
        fruits.append(estructura1(precio: 22, nombre: "Fresa", descripcion: "Bolsa de Fresas 150g, Precio $22 "))
        fruits.append(estructura1(precio: 18, nombre: "Piña", descripcion: "Bolsa de piña 120g, Precio $18"))
        fruits.append(estructura1(precio: 34, nombre: "Sandia", descripcion: "Bolsa de sandia  150g, Precio $34"))
        fruits.append(estructura1(precio: 60, nombre: "Arandano", descripcion: "Bolsa de arandano 500g. Precio $60"))
        fruits.append(estructura1(precio: 56, nombre: "Uvas", descripcion: "Bolsa de Uvas 450g, Precio $56"))
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruits.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CeldaTableViewCell
        
        //if indexPath.row % 2 == 0{
          //cell.backgroundColor = UIColor.orange
        //}
       //else{
                //cell.backgroundColor = UIColor.yellow
                
        //}
        
        
        cell.titulo.text = fruits[indexPath.row].nombre
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(fruits[indexPath.row])
        
        let cell = tableView.cellForRow(at: indexPath)
        cell?.accessoryType = .checkmark
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, sourceview, completionHandler) in
            
            self.fruits.remove(at: indexPath.row)
            self.tablita.deleteRows(at: [indexPath], with: .fade )
            completionHandler(true)
        }
        
        let shareAction = UIContextualAction(style: .normal, title: "Share") { (action, sourceview, completionHandler) in
            
            let defaultTex = "Compartiendo a: \(self.fruits[indexPath.row])"
            
            let activityController = UIActivityViewController(activityItems: [defaultTex], applicationActivities: nil)
            
            self.present(activityController, animated: true, completion: nil)
            
            completionHandler(true)
        }
        
        shareAction.backgroundColor = UIColor.green
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction, shareAction])
        
        
        return swipeConfiguration
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segunda"{
            
            let indexPath = tablita.indexPathForSelectedRow
            
            let destino = segue.destination as! SecondViewController
            destino.vieneDeVistaUno = fruits[(indexPath?.row)!].nombre
            //destino.vieneDeVistaDescrip = "\(fruits[(indexPath?.row)!].descripcion)  $ \(fruits[(indexPath?.row)!].precio)"
            destino.vieneDeVistaDescrip = "\(fruits[(indexPath?.row)!].descripcion)"
            
            destino.incremento = fruits[(indexPath?.row)!].precio
        }
    }
    
    @IBAction func unwindSecondView( segue: UIStoryboardSegue){
        if let origin = segue.source as? SecondViewController{
            let data = origin.dataFromSecondView
            let aux  = Float(Resultado.text!)
            let aux2 = Float(data)
            Resultado.text = String(aux! + aux2 )
        }
    }
    
}

