//
//  ViewController.swift
//  TableView1
//
//  Created by Germán Santos Jaimes on 8/30/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var Resultado: UILabel!
    
    
    @IBOutlet weak var tablita: UITableView!
    var fruits = [estructura1] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fruits.append(estructura1(precio: 12, nombre: "Manzana", descripcion: "100g"))
        fruits.append(estructura1(precio: 10, nombre: "Plátano", descripcion: "200g"))
        fruits.append(estructura1(precio: 15, nombre: "Fresa", descripcion: "150g"))
        fruits.append(estructura1(precio: 15, nombre: "Piña", descripcion: "120g"))
        fruits.append(estructura1(precio: 15, nombre: "Sandia", descripcion: "150g"))
        fruits.append(estructura1(precio: 15, nombre: "Arandano", descripcion: "140g"))
        fruits.append(estructura1(precio: 15, nombre: "Uvas", descripcion: "150g"))
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruits.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CeldaTableViewCell
        
        //if indexPath.row % 2 == 0{
          //cell.backgroundColor = UIColor.orange
        //}
       //else{
                //cell.backgroundColor = UIColor.yellow
                
        //}
        
        
        cell.titulo.text = fruits[indexPath.row].nombre
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(fruits[indexPath.row])
        
        let cell = tableView.cellForRow(at: indexPath)
        cell?.accessoryType = .checkmark
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, sourceview, completionHandler) in
            
            self.fruits.remove(at: indexPath.row)
            self.tablita.deleteRows(at: [indexPath], with: .fade )
            completionHandler(true)
        }
        
        let shareAction = UIContextualAction(style: .normal, title: "Share") { (action, sourceview, completionHandler) in
            
            let defaultTex = "Compartiendo a: \(self.fruits[indexPath.row])"
            
            let activityController = UIActivityViewController(activityItems: [defaultTex], applicationActivities: nil)
            
            self.present(activityController, animated: true, completion: nil)
            
            completionHandler(true)
        }
        
        shareAction.backgroundColor = UIColor.green
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction, shareAction])
        
        
        return swipeConfiguration
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segunda"{
            
            let indexPath = tablita.indexPathForSelectedRow
            
            let destino = segue.destination as! SecondViewController
            destino.vieneDeVistaUno = fruits[(indexPath?.row)!].nombre
            destino.incremento = fruits[(indexPath?.row)!].precio
        }
    }
    
    @IBAction func unwindSecondView( segue: UIStoryboardSegue){
        if let origin = segue.source as? SecondViewController{
            let data = origin.dataFromSecondView
            let aux  = Float(Resultado.text!)
            let aux2 = Float(data)
            Resultado.text = String(aux! + aux2 )
        }
    }
    
}

