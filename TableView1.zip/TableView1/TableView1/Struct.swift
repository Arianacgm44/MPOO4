//
//  E.swift
//  TableView1
//
//  Created by Usuario invitado on 4/10/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct estructura1 {
    
    var precio : Double
    var nombre : String
    var descripcion : String
 
    
}
