//
//  GermanTableViewCell.swift
//  TableView1
//
//  Created by Germán Santos Jaimes on 9/11/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class GermanTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
