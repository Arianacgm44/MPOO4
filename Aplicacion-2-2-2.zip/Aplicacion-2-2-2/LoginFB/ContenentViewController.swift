//
//  ContenentViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 04/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class ContenentViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var abs = [String]()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "celda1", for: indexPath) as! RespuestaTableViewCell
        cell.Respuesta.text = abs[indexPath.row] 
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
 
        let cell = tableView.cellForRow(at: indexPath)
        let a = tableView.dequeueReusableCell(withIdentifier: "celda1", for: indexPath) as! RespuestaTableViewCell
        var answerSelected = ""
        if answerSelected == "" {
            answerSelected = self.abs[indexPath.row]
            cell?.accessoryType = .checkmark


        }
        else {
            answerSelected = self.abs[indexPath.row]
            cell?.accessoryType = .checkmark
 

            
        }


    }
    

    @IBOutlet weak var Pregunta: UITextView!
    @IBOutlet weak var Numero: UILabel!
    var text = String()
    var pagesIndex = 0
    var text1 = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        Pregunta.text = text
        Numero.text = text1

 
    }


}
