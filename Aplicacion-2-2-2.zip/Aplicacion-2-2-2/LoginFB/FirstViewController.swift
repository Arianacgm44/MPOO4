//
//  FirstViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 06/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase
class FirstViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "s", for: indexPath)
        return cell
    }
    

    
    @IBOutlet weak var table1: UITableView!
    @IBOutlet var table2: UITableView!
    var Respuestas = [[String]]()
    var res = [String]()
    var Preguntas = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        let a = ""
        let db = Firestore.firestore()
        let docRef = db.collection("Materias").document(a)
        
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
                guard let dictionary = document.data() as? [String: Any] else {return}
                guard let dictionaryArray = dictionary["preguntas"] as? [[String: Any]] else {return}
                for i in 0...4{
                    self.res.append(dictionaryArray[i]["a"]! as! String)
                    self.res.append(dictionaryArray[i]["b"]! as! String)
                    self.res.append(dictionaryArray[i]["c"]! as! String)
                    self.res.append(dictionaryArray[i]["d"]! as! String)
                    self.Respuestas.append(self.res)
                    self.res.removeAll()
                }
                for j in 0...4{
                    self.Preguntas.append(dictionaryArray[0]["reactivo "]! as! String)
                }
                
            }
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == table1,
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomOne") as? FirstTableViewCell {
            for i in 0...4{
                cell.First.text = Respuestas[0][i]
            }
            return cell
        } else if tableView == table2,
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTwo") as? SecondTableViewCell {
            return cell
        }
        
        return UITableViewCell()
    }
    

    
    
    
    
    
    
    
    
    
    

    


    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
}
