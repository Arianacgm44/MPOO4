//
//  SelectAvatarViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 20/11/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase
class SelectAvatarViewController: UIViewController {



    @IBOutlet weak var Avatar4: UIImageView!
    @IBOutlet weak var Avatar3: UIImageView!
    @IBOutlet weak var Avatar2: UIImageView!
    @IBOutlet weak var Avatar1: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }




}

