//
//  SecondTableViewCell.swift
//  tableview
//
//  Created by Cristian Lopez on 06/12/18.
//  Copyright © 2018 Cristian Lopez. All rights reserved.
//

import UIKit

class SqTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
