//
//  FinalViewController.swift
//  LoginFB
//
//  Created by macbook on 12/6/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class FinalViewController: UIViewController {

    @IBOutlet weak var Final: UILabel!
    @IBOutlet weak var calif: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        Final.text = "Puntaje final es"
        calif.text = "8"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
