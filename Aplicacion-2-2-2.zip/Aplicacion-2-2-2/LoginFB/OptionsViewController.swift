//
//  OptionsViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 20/11/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase




class OptionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
 
    


    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    var materias = ["Historia", "Español", "Fisica", "Matematicas", "Biologia", "Geografia"]
    var respuestasOptionViewController = [[String]]()
    var res = [String]()
    var preguntasOptionsViewController = [String]()
    var correcta = [String]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return materias.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! OptionsTableViewCell
        cell.Name.text = materias[indexPath.row]
        cell.ImagenMateria.image = UIImage(named: materias[indexPath.row] + ".jpg")
        return cell
    } 
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segunda"{
            
            let indexPath = Options.indexPathForSelectedRow
            
            let destino = segue.destination as! SecondQuestionViewController
            destino.vieneDeVistaUno = materias[(indexPath?.row)!]
            print(destino)
            let db = Firestore.firestore()
            let docRef = db.collection("Materias").document("Fisica")
            
            docRef.getDocument { (document, error) in
                if let document = document, document.exists {
                    let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
                    guard let dictionary = document.data() as? [String: Any] else {return}
                    guard let dictionaryArray = dictionary["preguntas"] as? [[String: Any]] else {return}
                    //let answer = dictionaryArray.first!["a"]
                    for i in 0...4{
                        self.res.append(dictionaryArray[i]["a"]! as! String)
                        self.res.append(dictionaryArray[i]["b"]! as! String)
                        self.res.append(dictionaryArray[i]["c"]! as! String)
                        self.res.append(dictionaryArray[i]["d"]! as! String)
                        self.respuestasOptionViewController.append(self.res)
                        self.res.removeAll()
                    }
                    print("Respuestas", self.respuestasOptionViewController)
                    let destino1 = segue.destination as! SecondQuestionViewController
                    destino1.Respuestas = self.respuestasOptionViewController
                    print(type(of: self.respuestasOptionViewController))
                    
                    for j in 0...4{
                        self.preguntasOptionsViewController.append(dictionaryArray[0]["reactivo "]! as! String)
                    }
                    print(self.preguntasOptionsViewController)
                    print(type(of: self.preguntasOptionsViewController))
                    let destino2 = segue.destination as! SecondQuestionViewController
                    destino2.Preguntas = self.preguntasOptionsViewController
                    print(document.data())
                    for i in 0...4{
                        self.correcta.append(dictionaryArray[i]["respuesta"]! as! String)
                    }
                    let destino3 = segue.destination as! SecondQuestionViewController
                    destino3.correcta = self.correcta  
                    print("respuesta", self.correcta)

                    // dictionaryArray[1]["a"]!
 
                } else {
                    print("Document does not exist")
                }
            }
            
        }
    }

    @IBOutlet weak var Options: UITableView!


 
}
