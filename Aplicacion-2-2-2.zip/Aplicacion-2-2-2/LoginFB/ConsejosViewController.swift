//
//  ConsejosViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 03/12/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class ConsejosViewController: UIViewController, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return consejos.count
    }
    
    var consejos = ["Esfuerzate", "Despierta temprano", "Come bien", "No llegues tarde a clase", "Alejate del ruido"]
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "consejo", for: indexPath) as! ConsejoCollectionViewCell
        
        cell.backgroundColor = UIColor.red
        cell.etiqueta.text = consejos[(indexPath.row)]
        
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    


}
