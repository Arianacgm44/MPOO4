//
//  TableViewController.swift
//  LoginFB
//
//  Created by macbook on 11/15/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController{
    var materias: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        materias = ["Matematicas","Español", "Geografia", "Biologia"]
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let numberOfRows = materias.count
        return numberOfRows
    }
    
    func tableView(tableView: UITableView, cellForRowsAtIndexPath IndexPath:NSIndexPath) ->UITableViewCell{
        let celda = tableView.dequeueReusableCellWithIdentifier(celdaIdentifier, forIndexPath: IndexPath)
        
        let materia = materias[IndexPath.row]
        
        // Configure Cell
        celda.textLabel?.text = materias
        
        return celda
    }
    
}
