//
//  botoncito.swift
//  TableView2
//
//  Created by Germán Santos Jaimes on 9/10/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class botoncito: UIButton {

    override func awakeFromNib() {
     layer.borderColor = UIColor.black.cgColor
        
    }

}
