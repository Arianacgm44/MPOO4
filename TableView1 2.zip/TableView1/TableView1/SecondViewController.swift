//
//  SecondViewController.swift
//  TableView1
//
//  Created by Germán Santos Jaimes on 8/30/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var name: UILabel!
    var vieneDeVistaUno: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Valor.text = String (dataFromSecondView)
        
        name.text = vieneDeVistaUno
    }
    @IBOutlet weak var Valor: UILabel!
    var dataFromSecondView : Int = 0
   
    
    @IBAction func updateValue(_ sender: UIButton) {
        dataFromSecondView = dataFromSecondView + 1
        Valor.text = String(dataFromSecondView)
    }
    

    }

