//
//  Data.swift
//  User
//
//  Created by Cristian Lopez on 17/10/18.
//  Copyright © 2018 Cristian Lopez. All rights reserved.
//

import Foundation

struct Data {
    var name : String
    var mail : String
    var password : String
}
