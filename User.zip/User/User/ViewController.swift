//
//  ViewController.swift
//  User
//
//  Created by Cristian Lopez on 16/10/18.
//  Copyright © 2018 Cristian Lopez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var User1: UITextField!
    @IBOutlet weak var password: UILabel!
    @IBOutlet weak var Password1: UITextField!
    @IBOutlet weak var user: UILabel!
    @IBOutlet weak var mail1: UILabel!
    @IBOutlet weak var mail: UITextField!
    var mail2 : String = ""
    var user2 : String = ""
    var pass : String = ""
    var data = [Data]()
    var a = 0
    var dic = ["s":"s"]
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        mail1.text = "Correo"
        password.text = "Contraseña"
        user.text = "Nombre de Usuario"
        if let dato = defaults.object(forKey: "dato") as? String{
            mail.text = dato
        }
        if let dato1 = defaults.object(forKey: "dato") as? String{
            User1.text = dato1
        }
        if let dato2 = defaults.object(forKey: "dato") as? String{
            Password1.text = dato2
        }

 
    }
    
    @IBAction func Register(_ sender: UIButton) {
        let defaults = UserDefaults.standard
        
        if let valor = mail.text{
            defaults.set(valor, forKey: "dato")
        }
        if let valor1 = User1.text{
            defaults.set(valor1, forKey: "dato")
        }
        if let valor2 = Password1.text{
            defaults.set(valor2, forKey: "dato")
        }
        
        if a==1{
            performSegue(withIdentifier: "second", sender: self)
        }
        
        
        
        
        mail2 = mail.text!
        user2 = User1.text!
        pass = Password1.text!
        print(type(of: mail2))
        data.append(Data(name: user2, mail: mail2, password: pass))

        
        
        
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "second"{
            let destination = segue.destination as? SecondViewController
            destination?.first = mail2
            
        }

    }

   override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "second" {
            
            if Password1.text == "" {
                
                print("a")
                
                return false
            }
                
            else {
                return true
            }
        }
        
        // by default, transition
        return true
    }

}


