//
//  FirstViewController.swift
//  User
//
//  Created by Cristian Lopez on 18/10/18.
//  Copyright © 2018 Cristian Lopez. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func Login(_ sender: UIButton) {
    }
    
    @IBAction func Register(_ sender: UIButton) {
    }
    
    @IBAction func unwindSecondView( segue: UIStoryboardSegue){
        
    }
    
}
